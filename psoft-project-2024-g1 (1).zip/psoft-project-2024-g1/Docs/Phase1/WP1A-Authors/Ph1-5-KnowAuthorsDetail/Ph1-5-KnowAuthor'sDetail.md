# WP#1A – Authors
## 5. Know Author's Details
As Librarian or Reader I want to know an author’s detail given its author number.
