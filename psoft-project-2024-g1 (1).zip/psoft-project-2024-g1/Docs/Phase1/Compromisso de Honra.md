# Eduardo Silva - 1220956
Fiquei encarregue de desenvolver o WP dos readers

# André Alvarenga - 1220966
Fiquei encarregue de desenvolver o WP dos authors

# Gonçalo Ferreira - 1221092
Fiquei encarregue de desenvolver o WP dos books

# Ricardo França - 1221708
Fiquei encarregue de desenvolver o WP dos lendings
