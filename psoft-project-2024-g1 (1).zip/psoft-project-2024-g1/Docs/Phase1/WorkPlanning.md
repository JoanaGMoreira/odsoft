# Work Planning

| **Milestone** | Milestone Date | **Issues**                        | Issue Date |
|:--------------|:---------------|:----------------------------------|:-----------|
| **1**         | 28/4           | Domain Objects (Ricardo)          | 26/4       |
|               |                | Create Reader (Edu)               | 28/4       |
|               |                | Get Author (Alvarenga)            | 28/4       |
|               |                | Update Book (Gonçalo)             | 28/4       |
| **2**         | TBD            | Glossary                          |            |
|               |                | Business rules for domain objects |            |
|               |                | CRUD for all USs                  |            |
