# Auto Avaliação:
Eduardo: 16
Ricardo: 16
André: 16
Gonçalo: 16
