# Photo

Photo to be attributed to a Reader, Author, or Book

> [Attributes](#attributes)
>
> [Relevant Use Cases](#Relevant-Use-Cases)
>
> [Customer Clarifications](#Customer-Clarifications)

### Attributes
- photoFile


### Relevant Use Cases
- #### Phase 1
    - (WP#1A.xxx : As Librarian ...

### Customer Clarifications
>[Q: É esperado alterar o update, feito na fase 1, para que seja possivel os authors já criados colocarem uma foto deles?](https://moodle.isep.ipp.pt/mod/forum/discuss.php?d=29862#p37877)
>
>A: sim

>[Q: Gostaria de saber os critérios de aceitação (Acceptance Criteria), das us7, us8, us9 e us10 do Books da fase 2. ](https://moodle.isep.ipp.pt/mod/forum/discuss.php?d=29649#p37557)
>
>A: [...] this is a refinement of the existing use case. the user may choose to add a photo of the book cover. the photo must be in the jpeg or png format and at most 20 KB [...]
