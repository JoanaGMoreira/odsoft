# Genre

Succinctly characterizes books in the library.

> [Attributes](#attributes)
>
> [Relevant Use Cases](#Relevant-Use-Cases)
>
> [Customer Clarifications](#Customer-Clarifications)

### Attributes
- Genre

### Relevant Use Cases
- #### Phase 1
    - (WP#1A.xxx : As Librarian ...)

### Customer Clarifications
>[Q: Quais são os critério de aceitação (acceptance criteria) da us07?](https://moodle.isep.ipp.pt/mod/forum/discuss.php?d=28891#p36487)
>
>A: [...] Género e autor são obrigatórios  

>[Q: Os genres dos livros são uma lista dada pelo cliente, é o librarian que a faz e vai adicionando ou são atribuidos de uma outra forma?](https://moodle.isep.ipp.pt/mod/forum/discuss.php?d=28911#p36509)
>
>A: Os géneros de livros configurados na base de dados via bootstrapping (WP #0A)
>
>[Q: Sobre a pergunta 3, creio que ainda não ficou claro se os 'genre's são escolhidos pelo 'librarian' (na hora de registar um livro) de uma lista existente (e eventualmente mutável), ou se são escritos manualmente pelo 'librarian'.](https://moodle.isep.ipp.pt/mod/forum/discuss.php?d=28911#p36699)
> 
>A: 
