# Birth Date

Date of birth of a [Reader](../Aggregates/Reader.md).

> [Attributes](#attributes)
>
> [Relevant Use Cases](#Relevant-Use-Cases)
>
> [Customer Clarifications](#Customer-Clarifications)

### Attributes
- Date of birth
  - NOTA - Ricardo: https://stackoverflow.com/questions/40075780/java-best-practice-for-date-manipulation-storage-for-geographically-diverse-user




### Relevant Use Cases
- #### Phase 1
    - (WP#1A.xxx : As Librarian ...

### Customer Clarifications

>[Q: Existe uma idade mínima?](https://moodle.isep.ipp.pt/mod/forum/discuss.php?d=28876#p36472)
>
>A: Leitor deve ter pelo menos 12 anos

>[Q: Existe uma idade máxima?](https://moodle.isep.ipp.pt/mod/forum/discuss.php?d=28876#p36472)
>
>A: não

>[Q: A idade influencia algo? (Acesso a certas funcionalidades/livros, Recomendação de livros)](https://moodle.isep.ipp.pt/mod/forum/discuss.php?d=28876#p36472)
>
>A: de momento esse controlo é feito fisicamente pelo bibliotecário e fora do sistema