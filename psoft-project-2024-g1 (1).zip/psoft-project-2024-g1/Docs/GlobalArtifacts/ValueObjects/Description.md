#Description

Short biography of an [Author](../Aggregates/Author.md).

> [Attributes](#attributes)
>
> [Relevant Use Cases](#Relevant-Use-Cases)
>
> [Customer Clarifications](#Customer-Clarifications)

### Attributes
- Description


### Relevant Use Cases
- #### Phase 1
    - (WP#1A.xxx : As Librarian ...

### Customer Clarifications
>[Q: Quão breve deverá ser a descrição? Existe um limite de caracteres?
](https://moodle.isep.ipp.pt/mod/forum/discuss.php?d=28907#p36574)
>
>A: no máximo 4096 carcateres
