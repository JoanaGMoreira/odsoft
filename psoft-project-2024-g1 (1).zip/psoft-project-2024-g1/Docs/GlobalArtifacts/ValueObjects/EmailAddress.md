# Email Address

Address used to contact people or institutions via the Internet.

> [Attributes](#attributes)
>
> [Relevant Use Cases](#Relevant-Use-Cases)
>
> [Customer Clarifications](#Customer-Clarifications)

### Attributes
- (...)


### Relevant Use Cases
- #### Phase 1
    - (WP#1A.xxx : As Librarian ...

### Customer Clarifications

>[Q: Um utilizador pode ter vários emails? ](https://moodle.isep.ipp.pt/mod/forum/discuss.php?d=28876#p36472)
>
>A: não

>[Q: Um mesmo email pode pertencer a vários utilizadores?](https://moodle.isep.ipp.pt/mod/forum/discuss.php?d=28876#p36472)
>
>A: não

>[Q: É necessário validar se o email realmente existe?](https://moodle.isep.ipp.pt/mod/forum/discuss.php?d=28876#p36472)
>
>A: não. basta que esteja no formato correto

>[Q: Permite todos os dominios de email? Ou apenas um grupo (gmail.com, hotmail.com, isep.ipp.pt)? Se sim, quais? ](https://moodle.isep.ipp.pt/mod/forum/discuss.php?d=28876#p36472)
>
>A: qualquer dominio