# Author Bio

Short biography of an [Author](../Aggregates/Author.md).

> [Attributes](#attributes)
>
> [Relevant Use Cases](#Relevant-Use-Cases)
>
> [Customer Clarifications](#Customer-Clarifications)

### Attributes
- Bio


### Relevant Use Cases
- #### Phase 1
    - (WP#1A.xxx : As Librarian ...

### Customer Clarifications
>[Q: Gostava de saber se quando o bibliotecário cria a bio do autor, apenas é constituído por texto ou tem outro campo?](https://moodle.isep.ipp.pt/mod/forum/discuss.php?d=28907#p36504)
>
>A:  a breve biografia do autor deve permitir conteudo HTML

>[Q: Quão breve deverá ser a biografia? Existe um limite de caracteres?
](https://moodle.isep.ipp.pt/mod/forum/discuss.php?d=28907#p36574)
>
>A: no máximo 4096 carcateres
