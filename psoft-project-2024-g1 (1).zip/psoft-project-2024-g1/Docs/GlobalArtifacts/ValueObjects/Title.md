# Title

Books title.

> [Attributes](#attributes)
>
> [Relevant Use Cases](#Relevant-Use-Cases)
>
> [Customer Clarifications](#Customer-Clarifications)

### Attributes
- Title

### Relevant Use Cases
- #### Phase 1
    - (WP#1A.xxx : As Librarian ...)

### Customer Clarifications

>[Q: Apenas devem ser permitidas letras? ](https://moodle.isep.ipp.pt/mod/forum/discuss.php?d=28876#p36472)
>
>A: qualquer caracter alfanumérico

>[Q: Pode ser deixado vazio? ](https://moodle.isep.ipp.pt/mod/forum/discuss.php?d=28876#p36472)
>
>A: não

>[Q: Existem algumas palavras proibidas?](https://moodle.isep.ipp.pt/mod/forum/discuss.php?d=28876#p36472)
>
>A: **sim. deve existir no sistema uma configuração de "palavras proibidas" que não são aceites no titulo do livro**