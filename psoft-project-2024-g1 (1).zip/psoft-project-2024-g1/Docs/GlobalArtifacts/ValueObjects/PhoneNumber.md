# Phone Number

Telephone / cellphone used to contact people or institutions.

> [Attributes](#attributes)
>
> [Relevant Use Cases](#Relevant-Use-Cases)
>
> [Customer Clarifications](#Customer-Clarifications)

### Attributes
- Number


### Relevant Use Cases
- #### Phase 1
    - (WP#1A.xxx : As Librarian ...)

### Customer Clarifications
>[Q: Um utilizador pode ter vários números de telefone?](https://moodle.isep.ipp.pt/mod/forum/discuss.php?d=28876#p36472)
>
>A: não

>[Q: Um mesmo número de telefone pode ser usado em vários leitores?](https://moodle.isep.ipp.pt/mod/forum/discuss.php?d=28876#p36472)
>
>A: sim

>[Q: O número de telefone deve ser português ou admite outros países?](https://moodle.isep.ipp.pt/mod/forum/discuss.php?d=28876#p36472)
>
>A: basta considerar numeros portugueses de momento


>[Q: O número de telefone deve ser móvel ou pode ser fixo?](https://moodle.isep.ipp.pt/mod/forum/discuss.php?d=28876#p36472)
>
>A: ambos