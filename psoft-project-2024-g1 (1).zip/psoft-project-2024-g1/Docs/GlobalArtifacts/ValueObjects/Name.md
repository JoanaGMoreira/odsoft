# Name

Commonly used to identify people.

> [Attributes](#attributes)
>
> [Relevant Use Cases](#Relevant-Use-Cases)
>
> [Customer Clarifications](#Customer-Clarifications)

### Attributes
- Name

### Relevant Use Cases
- #### Phase 1
    - (WP#1A.xxx : As Librarian ...)

### Customer Clarifications
>[Q: É requisitado apenas o 1º e ultimo nome? 3, 4, 5 nomes?](https://moodle.isep.ipp.pt/mod/forum/discuss.php?d=28876#p36472)
>
>A: não necessitamos distinguir quantos nomes a pessoa tem

>[Q: São permitidos títulos? (Sr., Dr., …)](https://moodle.isep.ipp.pt/mod/forum/discuss.php?d=28876#p36472)
>
>A: nao há necessidade de capturar esta informação

>[Q: Apenas devem ser permitidas letras? ](https://moodle.isep.ipp.pt/mod/forum/discuss.php?d=28876#p36472)
>
>A: qualquer caracter alfanumérico

>[Q: Deve ser apenas permitido o alfabeto latino? Devem ser permitido outros alfabetos (cirilico, grego, ...) ou sistemas de escrita (árabe, hebraico, ...)? ](https://moodle.isep.ipp.pt/mod/forum/discuss.php?d=28876#p36472)
>
>A: basta considerar o alfabeto Latino

>[Q: Pode ser deixado vazio? ](https://moodle.isep.ipp.pt/mod/forum/discuss.php?d=28876#p36472)
>
>A: não

>[Q: Pode ter apenas espaços?](https://moodle.isep.ipp.pt/mod/forum/discuss.php?d=28876#p36472)
>
>A: não

>[Q: Existem algumas palavras proibidas?](https://moodle.isep.ipp.pt/mod/forum/discuss.php?d=28876#p36472)
>
>A: **sim. deve existir no sistema uma configuração de "palavras proibidas" que não são aceites no nome do Leitor**