# Password

Used in conjunction with a [username](Username.md) to authenticate a [user](../Entities/User.md) in the system.

> [Attributes](#attributes)
>
> [Relevant Use Cases](#Relevant-Use-Cases)
>
> [Customer Clarifications](#Customer-Clarifications)

### Attributes
- Password


### Relevant Use Cases
- #### Phase 1
    - (WP#1A.xxx : As Librarian ...

### Customer Clarifications
>Q:
>
>A: