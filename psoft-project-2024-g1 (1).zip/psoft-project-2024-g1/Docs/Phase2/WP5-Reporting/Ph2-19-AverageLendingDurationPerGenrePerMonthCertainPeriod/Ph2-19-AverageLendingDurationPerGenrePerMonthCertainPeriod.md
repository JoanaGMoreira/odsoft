# WP#5.19 Get Average Lending Duration Per Genre Per Month Over Period
## 1. Requirements Engineering
### 1.1. User Story Description

As Librarian I want to know the Average lending duration Per genre per month for a certain period

### 1.2. Customer Specifications and Clarifications

### 1.3. Acceptance Criteria
- Lista ordenada por mês e género com a duração média dos empréstimos nesse mês para esse género, para um dado período

### 1.4. Found out Dependencies
### 1.5 Input and Output Data

**Input Data:**

* Typed data:
  * (...)

**Output Data:**

* (In)success of the operation



## 2. Design
### 2.1. Sequence Diagram (SD)

[//]: # (<img src="Ph1-15-LendBook-SD-WP_4A_15_Lend_Book.svg" alt="WP_4A_15_Lend_Book">)

## 4. Tests
## 5. Observations
