package pt.psoft.g1.psoftg1.lendingmanagement.api;

import org.mapstruct.*;
import pt.psoft.g1.psoftg1.lendingmanagement.model.Fine;
import pt.psoft.g1.psoftg1.lendingmanagement.model.Lending;
import pt.psoft.g1.psoftg1.lendingmanagement.model.LendingNumber;

import java.util.Optional;

@Mapper(componentModel = "spring")
public abstract class FineViewMapper{
/*
    public abstract FineView toFineView(Fine fine);
*/
/*
    public abstract Iterable<FineView> toFineView(Iterable<Fine> fines);
*/

/*
    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    public abstract Fine partialUpdate(FineView fineView, @MappingTarget Fine fine);
*/


}