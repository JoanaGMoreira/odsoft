package pt.psoft.g1.psoftg1.shared.services;

public interface ForbiddenNameService {
    void loadDataFromFile(String filePath);
}
